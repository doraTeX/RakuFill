function s(n,t){return chrome.i18n.getMessage(n,t)||n}function i(n){return n.key==="Enter"&&!n.isComposing&&n.keyCode!==229}export{i,s as t};
